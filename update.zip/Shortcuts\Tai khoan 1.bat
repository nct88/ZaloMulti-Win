@echo off
chcp 65001 >nul
start "" powershell.exe -ExecutionPolicy Bypass -WindowStyle Hidden -File "C:\Users\truongit\ZaloMulti-Win\ZaloMulti.ps1" -LaunchInstance "Tài khoản 1"
# Bản quyền thuộc về truong.it - Tác giả: truong.it
